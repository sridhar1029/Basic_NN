# Basic Neural Net Package

This is a simple packkage that implements neural nets from scratch. This package can help you develop small neural net models, and will give you experience of implementing a neural network from scratch. The package can not be used for large scale DL models, it is created for the purpose of learning to implement Neural Nets from scratch.

## Who is this package for - 

The neural net class in this package is built using basic numpy functions, giving you a deep dive on how the backpropogation algorithm works. This package is for beginers who want to get started with neural nets and want to implement it from scratch.

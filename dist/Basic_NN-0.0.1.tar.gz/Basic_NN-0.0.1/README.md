# Basic Neural Net Package

This is a simple packkage that implements neural nets from scratch.
This package can help you develop small neural net models, and will give you experience of implementing a neural network from scratch.
The package can not be used for large scale DL models, it is created for the purpose of learning to implement Neural Nets from scratch.
